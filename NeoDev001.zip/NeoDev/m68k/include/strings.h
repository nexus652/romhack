/* # $Id: strings.h,v 1.1 2001/05/31 08:31:54 fma Exp $ */

#ifndef __STRINGS_H__
#define __STRINGS_H__

#include <stdlib.h>

#endif /* __STRINGS_H__ */
