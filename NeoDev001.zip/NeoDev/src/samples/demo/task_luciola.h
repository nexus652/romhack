/* $Id: task_luciola.h,v 1.1 2001/05/07 14:19:44 fma Exp $ */

#ifndef __TASK_LUCIOLA_H__
#define __TASK_LUCIOLA_H__

#include <task.h>
#include <video.h>

extern void task_luciola_small(PTASK myself);
extern void task_luciola_big(PTASK myself);
extern void task_bgdisp(PTASK myself);

#endif
