/* $Id: task_disp.h,v 1.1 2001/05/02 14:51:40 fma Exp $ */

#ifndef __TASK_DISP_H__
#define __TASK_DISP_H__

#include <task.h>

extern void task_disp(PTASK myself);

#endif
