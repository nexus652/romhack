/* $Id: task_disp.h,v 1.1 2001/04/24 14:52:26 fma Exp $ */

#ifndef __TASK_DISP_H__
#define __TASK_DISP_H__

#include <task.h>

extern void task_disp(PTASK myself);

#endif
