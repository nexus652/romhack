/* $Id: bouncing_block.h,v 1.1 2001/04/24 14:52:26 fma Exp $ */

#ifndef __BOUNCING_BLOCK_H__
#define __BOUNCING_BLOCK_H__

#include <task.h>

extern void boucing_block(PTASK myself, int x, int height, int angle, int step);

#endif
